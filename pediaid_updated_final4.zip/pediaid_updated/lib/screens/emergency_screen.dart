import 'package:flutter/material.dart';
import 'package:pediaid/models/patient_data.dart';
import 'package:pediaid/theme.dart';
import 'package:pediaid/models/indication.dart';
import 'package:pediaid/services/indication_service.dart';
import 'package:pediaid/screens/indication_detail_screen.dart';
import 'package:flutter/services.dart';
import 'dart:ui' show FontFeature;

class EmergencyScreen extends StatefulWidget {
  final PatientData patientData;

  const EmergencyScreen({super.key, required this.patientData});

  @override
  State<EmergencyScreen> createState() => _EmergencyScreenState();
}

class _EmergencyScreenState extends State<EmergencyScreen> {
  final _indicationService = IndicationService();
  List<Indication> _emergencyIndications = [];
  bool _isLoading = true;
  double _weight = 20.0;

  // Device recommendation helpers
  List<String> _getDeviceRecommendations() {
    final weight = _weight;
    final age = widget.patientData.ageYears ?? (weight / 10.0);
    // Laryngeal mask airway size: formula weight/20 + 1 (approx)
    final lmaSize = ((weight / 20.0) + 1.0);
    // Round to nearest 0.5
    final lmaRounded = (lmaSize * 2).round() / 2.0;
    String lma = lmaRounded.toStringAsFixed(lmaRounded % 1 == 0 ? 0 : 1);
    // Guedel (oropharyngeal) airway sizes by weight
    int opa;
    if (weight < 9) {
      opa = 50;
    } else if (weight < 18) {
      opa = 60;
    } else if (weight < 24) {
      opa = 70;
    } else if (weight < 36) {
      opa = 80;
    } else {
      opa = 90;
    }
    // Endotracheal tube (cuffed) size by age
    final ettCuffed = age != null ? ((age / 4.0) + 3.5) : ((weight / 10.0) + 3.5);
    // Laryngoscope blade suggestion by age
    int blade;
    if (age != null) {
      if (age < 1) {
        blade = 0;
      } else if (age < 2) {
        blade = 1;
      } else if (age < 8) {
        blade = 2;
      } else if (age < 12) {
        blade = 3;
      } else {
        blade = 4;
      }
    } else {
      blade = 2;
    }
    return [
      'Larynxmaske Größe: $lma',
      'Guedel-Tubus: ${opa} mm',
      'ETT (cuffed): ${ettCuffed.toStringAsFixed(1)} mm',
      'Laryngoskopspatel: Größe $blade',
    ];
  }

  Widget _deviceCard(BuildContext context) {
    final recs = _getDeviceRecommendations();
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'GERÄTEEMPFEHLUNGEN',
            style: Theme.of(context).textTheme.labelLarge?.copyWith(
                  letterSpacing: 1.5,
                  color: Colors.grey[700],
                ),
          ),
          const SizedBox(height: 8),
          ...recs.map((r) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    const Icon(Icons.medical_services, size: 20, color: Colors.black54),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        r,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _loadEmergencyIndications();
  }

  Future<void> _loadEmergencyIndications() async {
    final indications = await _indicationService.getAllIndications();
    setState(() {
      _emergencyIndications = indications.where((ind) => 
        ind.name == 'Anaphylaxie' || 
        ind.name == 'Reanimation' || 
        ind.name == 'Krampfanfall'
      ).toList();
      _weight = widget.patientData.weightKg ?? 20.0;
      _isLoading = false;
    });
  }

  Color _getColorForBand(String colorBand) {
    switch (colorBand) {
      case 'pink': return PediColors.pink;
      case 'red': return PediColors.red;
      case 'yellow': return PediColors.yellow;
      case 'blue': return PediColors.blue;
      case 'green': return PediColors.green;
      default: return PediColors.blue;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: const Text('NOTFALLMODUS', style: TextStyle(letterSpacing: 2, fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: _isLoading
        ? const Center(child: CircularProgressIndicator(color: Colors.white))
        : Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                _weightCard(context),
                const SizedBox(height: 16),
                _deviceCard(context),
                const SizedBox(height: 24),
                Expanded(child: _gridPrimary(context)),
                const SizedBox(height: 12),
                Text(
                  'Orientierungswerte – klinische Entscheidung erforderlich.\nQuelle: ERC 2025, DIVI 2024, DGKJ/AWMF – Stand 10/2025',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.white.withValues(alpha: 0.8)),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back),
                    label: const Text('Zurück zur Start'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 18),
                    ),
                  ),
                ),
              ],
            ),
          ),
    );
  }

  Widget _weightCard(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'GEWICHT',
            style: Theme.of(context).textTheme.labelLarge?.copyWith(
                  letterSpacing: 1.5,
                  color: Colors.grey[700],
                ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${_weight.toStringAsFixed(1)} kg',
                style: Theme.of(context).textTheme.displayMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
              ),
              // Optionally show quick-select chips for common weights
              Row(
                children: [5, 10, 15, 20, 30, 40, 50].map((w) {
                  final selected = (_weight - w).abs() < 0.1;
                  final color = selected ? PediColors.blue : PediColors.blue.withValues(alpha: 0.15);
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 2),
                    child: ChoiceChip(
                      label: Text('$w'),
                      selected: selected,
                      selectedColor: PediColors.blue,
                      labelStyle: TextStyle(color: selected ? Colors.white : PediColors.blue),
                      backgroundColor: color,
                      onSelected: (_) => setState(() => _weight = w.toDouble()),
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: PediColors.blue,
              thumbColor: PediColors.blue,
              overlayColor: PediColors.blue.withValues(alpha: 0.2),
            ),
            child: Slider(
              value: _weight,
              min: 2,
              max: 80,
              divisions: 78,
              label: '${_weight.toStringAsFixed(1)} kg',
              onChanged: (val) => setState(() => _weight = val),
            ),
          ),
        ],
      ),
    );
  }

  Widget _weightChips() {
    final bands = <double, Color>{
      5: PediColors.pink,
      10: PediColors.red,
      15: PediColors.purple,
      20: PediColors.yellow,
      30: PediColors.blue,
      40: PediColors.orange,
      50: PediColors.green,
    };
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: bands.entries.map((e) {
          final selected = (_weight - e.key).abs() < 0.1;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: ChoiceChip(
              selected: selected,
              label: Text('${e.key.toStringAsFixed(0)} kg'),
              selectedColor: e.value,
              labelStyle: TextStyle(color: selected ? Colors.white : e.value),
              backgroundColor: e.value.withValues(alpha: 0.15),
              onSelected: (_) {
                HapticFeedback.lightImpact();
                setState(() => _weight = e.key);
              },
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _gridPrimary(BuildContext context) {
    final tiles = _emergencyIndications.take(4).toList();
    return GridView.builder(
      // Im Notfallmodus sollen die Karten groß und leicht bedienbar sein. Durch
      // Verwendung einer Spalte werden die Kacheln über die gesamte Breite
      // dargestellt. childAspectRatio > 1 sorgt für zusätzliche Höhe.
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 1,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 1.3,
      ),
      itemCount: tiles.length,
      itemBuilder: (context, index) {
        final ind = tiles[index];
        final color = _getColorForBand(ind.colorBand);
        return _emergencyTile(context, ind, color);
      },
    );
  }

  Widget _emergencyTile(BuildContext context, Indication ind, Color color) {
    final keyDose = _buildKeyDose(ind);
    final keySecond = _buildKeySecond(ind);
    return InkWell(
      onTap: () => HapticFeedback.selectionClick(),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color, width: 3),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              ind.name,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: color,
                    fontSize: 24,
                  ),
            ),
            const SizedBox(height: 8),
            if (keyDose != null) keyDose,
            const SizedBox(height: 6),
            if (keySecond != null) keySecond,
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => IndicationDetailScreen(indication: ind, patientData: PatientData(ageYears: widget.patientData.ageYears, weightKg: _weight, heightCm: widget.patientData.heightCm)),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(backgroundColor: color, foregroundColor: Colors.white),
                child: const Text('Details'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget? _buildKeyDose(Indication ind) {
    // Show a compact primary dose card line
    if (ind.name == 'Anaphylaxie') {
      final doseMg = 0.01 * _weight; // mg/kg IM
      final ml = doseMg / 1.0; // 1 mg/ml
      return _doseRow('Adrenalin IM', '${doseMg.toStringAsFixed(2)} mg  •  ${ml.toStringAsFixed(2)} ml');
    }
    if (ind.name == 'Reanimation') {
      final j = 4.0 * _weight;
      return _doseRow('Defibrillation', '${j.toStringAsFixed(0)} J');
    }
    if (ind.name == 'Krampfanfall') {
      final doseMg = 0.2 * _weight; // Midazolam bukkal/nasal
      final ml = doseMg / 5.0; // 5 mg/ml
      return _doseRow('Midazolam', '${doseMg.toStringAsFixed(1)} mg  •  ${ml.toStringAsFixed(2)} ml');
    }
    return null;
  }

  Widget? _buildKeySecond(Indication ind) {
    if (ind.name == 'Reanimation') {
      final doseMg = 0.01 * _weight; // Adrenalin IV 0.01 mg/kg
      return _doseRow('Adrenalin IV', '${doseMg.toStringAsFixed(2)} mg');
    }
    if (ind.name == 'Asthma') {
      final doseMg = 0.15 * _weight; // Salbutamol
      return _doseRow('Salbutamol inh.', '${doseMg.toStringAsFixed(1)} mg');
    }
    return null;
  }

  Widget _doseRow(String title, String value) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.04),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
          Text(value, style: const TextStyle(fontFeatures: [FontFeature.tabularFigures()], fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
