import 'package:flutter/material.dart';
import 'package:pediaid/models/patient_data.dart';
import 'package:pediaid/theme.dart';
import 'package:pediaid/screens/indications_screen.dart';
import 'package:pediaid/screens/calculator_screen.dart';
import 'package:pediaid/screens/emergency_screen.dart';
import 'package:pediaid/screens/info_screen.dart';
import 'package:pediaid/services/settings_service.dart';
import 'package:pediaid/screens/formulas_screen.dart';
import 'package:pediaid/screens/norms_screen.dart';
import 'package:pediaid/screens/search_screen.dart';
import 'package:pediaid/screens/profile_screen.dart';
import 'package:pediaid/screens/checklists_screen.dart';
import 'package:pediaid/screens/favorites_screen.dart';
import 'package:pediaid/screens/comparison_screen.dart';
import 'package:pediaid/screens/guideline_search_screen.dart';
import 'package:pediaid/screens/schemata_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _settings = SettingsService();
  final _stats = StatisticsService();
  double _ageYears = 5.0;
  double _weightKg = 20.0;
  double _heightCm = 110.0;
  int _selectedIndex = 0;
  WeightUnit _weightUnit = WeightUnit.kg;
  LengthUnit _lengthUnit = LengthUnit.cm;
  String _profileBadge = 'Allgemein (Standard)';

  PatientData get _patientData => PatientData(
    ageYears: _ageYears,
    weightKg: _weightKg,
    heightCm: _heightCm,
  );

  List<Widget> get _screens => [
    _buildHomeContent(),
    IndicationsScreen(patientData: _patientData),
    CalculatorScreen(patientData: _patientData),
    const InfoScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final wu = await _settings.getWeightUnit();
    final lu = await _settings.getLengthUnit();
    final defAge = await _settings.getDefaultAgeYears();
    final defWeightKg = await _settings.getDefaultWeightKg();
    final level = await _settings.getProfileLevel();
    final state = await _settings.getProfileState();
    final area = await _settings.getProfileArea();
    final country = await _settings.getProfileCountry();
    // Für Länderebene den Ländercode als state-Parameter verwenden, damit
    // _composeProfile keine zusätzliche Variable benötigt.
    final regionOrCountry = level == 'country' ? country : state;
    setState(() {
      _weightUnit = wu;
      _lengthUnit = lu;
      _ageYears = defAge;
      _weightKg = defWeightKg;
      _profileBadge = _composeProfile(level, regionOrCountry, area);
    });
  }

  double _kgToLbs(double kg) => kg * 2.2046226218;
  double _lbsToKg(double lbs) => lbs / 2.2046226218;
  double _cmToIn(double cm) => cm / 2.54;
  double _inToCm(double inch) => inch * 2.54;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.1),
              blurRadius: 10,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: (index) {
            setState(() => _selectedIndex = index);
            // Nutzungsstatistiken erhöhen, wenn per BottomNavigation zu einem Screen gewechselt wird
            if (index == 1) {
              _stats.increment('indications');
            } else if (index == 2) {
              _stats.increment('calculator');
            } else if (index == 3) {
              _stats.increment('info');
            }
          },
          type: BottomNavigationBarType.fixed,
          elevation: 0,
          selectedItemColor: PediColors.blue,
          unselectedItemColor: Colors.grey,
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Start'),
            BottomNavigationBarItem(icon: Icon(Icons.medical_services), label: 'Indikationen'),
            BottomNavigationBarItem(icon: Icon(Icons.calculate), label: 'Rechner'),
            BottomNavigationBarItem(icon: Icon(Icons.info_outline), label: 'Info'),
          ],
        ),
      ),
    );
  }

  Widget _buildHomeContent() {
    final bsa = _patientData.calculateBSA();
    
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _profileBanner(context),
            const SizedBox(height: 16),
            Text(
              'PediAid',
              style: Theme.of(context).textTheme.displaySmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: PediColors.blue,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Pädiatrische Notfall-Hilfe',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 32),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Patientendaten', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 24),
                    _buildSimpleSlider('Alter (Jahre)', _ageYears, 0, 18, (val) => setState(() => _ageYears = val), PediColors.pink),
                    const SizedBox(height: 20),
                    _buildWeightSlider(),
                    const SizedBox(height: 20),
                    _buildHeightSlider(),
                    const SizedBox(height: 24),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: PediColors.yellow.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Körperoberfläche (m²)', style: Theme.of(context).textTheme.titleMedium),
                          Text('${bsa.toStringAsFixed(2)} m²', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text('Schnellzugriff', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              childAspectRatio: 1.2,
              children: [
                _buildQuickAccessCard(context, 'Indikationen', Icons.medical_services, PediColors.blue, () {
                  // Statistik erhöhen und zur Indikationsseite wechseln
                  _stats.increment('indications');
                  setState(() => _selectedIndex = 1);
                }),
                _buildQuickAccessCard(context, 'Rechner', Icons.calculate, PediColors.green, () {
                  _stats.increment('calculator');
                  setState(() => _selectedIndex = 2);
                }),
                _buildQuickAccessCard(context, 'Notfallmodus', Icons.emergency, PediColors.red, () {
                  _stats.increment('emergency');
                  Navigator.push(context, MaterialPageRoute(builder: (_) => EmergencyScreen(patientData: _patientData)));
                }),
                _buildQuickAccessCard(context, 'Suche', Icons.search, PediColors.purple, () {
                  _stats.increment('search');
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchScreen()));
                }),
                _buildQuickAccessCard(context, 'Formeln', Icons.functions, PediColors.orange, () {
                  _stats.increment('formulas');
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const FormulasScreen()));
                }),
                _buildQuickAccessCard(context, 'Normwerte', Icons.rule, PediColors.yellow, () {
                  _stats.increment('norms');
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const NormsScreen()));
                }),
                _buildQuickAccessCard(context, 'Checklisten', Icons.list_alt, PediColors.pink, () {
                  _stats.increment('checklists');
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const ChecklistsScreen()));
                }),
                // Neuer Schnellzugriff für Schemata
                _buildQuickAccessCard(context, 'Schemata', Icons.menu_book_outlined, PediColors.purple, () {
                  _stats.increment('schemata');
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const SchemataScreen()));
                }),
                _buildQuickAccessCard(context, 'Favoriten', Icons.star, PediColors.orange, () {
                  _stats.increment('favorites');
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const FavoritesScreen()));
                }),
                _buildQuickAccessCard(context, 'Vergleich', Icons.compare_arrows, PediColors.purple, () {
                  _stats.increment('comparison');
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const ComparisonScreen()));
                }),
                _buildQuickAccessCard(context, 'Leitlinien', Icons.menu_book, PediColors.green, () {
                  _stats.increment('guidelines');
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const GuidelineSearchScreen()));
                }),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSimpleSlider(String label, double value, double min, double max, Function(double) onChanged, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: Theme.of(context).textTheme.titleMedium),
            Text(value.toStringAsFixed(1), style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold, color: color)),
          ],
        ),
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            activeTrackColor: color,
            thumbColor: color,
            overlayColor: color.withValues(alpha: 0.2),
          ),
          child: Slider(value: value, min: min, max: max, onChanged: onChanged),
        ),
      ],
    );
  }

  Widget _buildWeightSlider() {
    final color = PediColors.blue;
    final unitLabel = _weightUnit == WeightUnit.kg ? 'kg' : 'lbs';
    final display = _weightUnit == WeightUnit.kg ? _weightKg : _kgToLbs(_weightKg);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Gewicht ($unitLabel)', style: Theme.of(context).textTheme.titleMedium),
            Text(display.toStringAsFixed(1), style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold, color: color)),
          ],
        ),
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            activeTrackColor: color,
            thumbColor: color,
            overlayColor: color.withValues(alpha: 0.2),
          ),
          child: Slider(
            value: _weightKg,
            min: 3,
            max: 80,
            onChanged: (val) => setState(() => _weightKg = val),
          ),
        ),
      ],
    );
  }

  Widget _buildHeightSlider() {
    final color = PediColors.green;
    final unitLabel = _lengthUnit == LengthUnit.cm ? 'cm' : 'inch';
    final display = _lengthUnit == LengthUnit.cm ? _heightCm : _cmToIn(_heightCm);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Größe ($unitLabel)', style: Theme.of(context).textTheme.titleMedium),
            Text(display.toStringAsFixed(1), style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold, color: color)),
          ],
        ),
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            activeTrackColor: color,
            thumbColor: color,
            overlayColor: color.withValues(alpha: 0.2),
          ),
          child: Slider(
            value: _heightCm,
            min: 50,
            max: 180,
            onChanged: (val) => setState(() => _heightCm = val),
          ),
        ),
      ],
    );
  }

  /// Builds a quick‑access card with unified styling. The card uses a tinted
  /// background derived from the provided [color] to aid recognition and
  /// barrierefreiheit. A tooltip and semantics label are added for
  /// screen‑reader support.
  Widget _buildQuickAccessCard(BuildContext context, String title, IconData icon, Color color, VoidCallback onTap) {
    // Create a soft tint for the card background by blending the color with white.
    final Color backgroundTint = color.withOpacity(0.12);
    return Semantics(
      label: 'Schnellzugriff $title',
      button: true,
      child: Tooltip(
        message: title,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Card(
            color: backgroundTint,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            elevation: 0,
            child: Container(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, size: 40, color: color),
                  const SizedBox(height: 12),
                  Text(
                    title,
                    textAlign: TextAlign.center,
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  String _composeProfile(String level, String? region, String? area) {
    // region repräsentiert entweder Land (bei Level 'country') oder Bundesland (bei Level 'state'/'area')
    if (level == 'area' && (region != null || area != null)) {
      return 'Profil: ${region ?? '-'} – ${area ?? '-'}';
    }
    if (level == 'state' && region != null) {
      return 'Profil: $region';
    }
    if (level == 'country' && region != null) {
      return 'Profil: $region';
    }
    return 'Profil: Allgemein (Standard)';
  }

  Widget _profileBanner(BuildContext context) {
    return InkWell(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen())).then((_) => _loadSettings()),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              const Icon(Icons.account_tree, color: Colors.blue),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Regionale Leitlinien-Profile', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text(_profileBadge, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey[700])),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }
}
