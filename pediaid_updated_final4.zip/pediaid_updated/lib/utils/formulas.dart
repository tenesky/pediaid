import 'dart:math' as math;

class PediFormulas {
  // Weight estimation
  static double estWeightKgByMonths(int months) {
    if (months <= 0) return 3.5; // newborn approx
    if (months <= 12) {
      return (months / 2.0) + 4.0;
    }
    // If >12 months but using months API, convert to years formula fallback
    final years = months / 12.0;
    return estWeightKgByYears(years);
  }

  static double estWeightKgByYears(double years) {
    if (years < 1.0) {
      // if under 1 year, approximate newborn 3.5 kg
      return 3.5;
    }
    if (years <= 10.0) {
      return (years * 2.0) + 8.0;
    }
    // beyond 10 years, keep linear suggestion (still MVP placeholder)
    return (years * 3.0) + 7.0;
  }

  // Height approximation
  static double estHeightCmByMonths(int months) {
    if (months <= 12) {
      return 50.0 + (months * 2.0);
    }
    final years = months / 12.0;
    return estHeightCmByYears(years);
  }

  static double estHeightCmByYears(double years) {
    if (years <= 12) {
      return (years * 6.0) + 77.0;
    }
    return (12 * 6.0) + 77.0 + ((years - 12) * 5.0);
  }

  // Body surface area (Mosteller)
  static double bsaMosteller(double heightCm, double weightKg) {
    if (heightCm <= 0 || weightKg <= 0) return 0.0;
    return math.sqrt((heightCm * weightKg) / 3600.0);
  }

  // Fluids
  static double fluidsDailyHollidaySegar(double weightKg) {
    // 100/50/20 rule (ml/day)
    if (weightKg <= 0) return 0.0;
    double remaining = weightKg;
    double total = 0.0;
    final first10 = math.min(10.0, remaining);
    total += first10 * 100.0;
    remaining -= first10;
    if (remaining > 0) {
      final next10 = math.min(10.0, remaining);
      total += next10 * 50.0;
      remaining -= next10;
    }
    if (remaining > 0) {
      total += remaining * 20.0;
    }
    return total; // ml/day
  }

  static double fluidsHourly421(double weightKg) {
    // 4-2-1 rule (ml/hour)
    if (weightKg <= 0) return 0.0;
    double remaining = weightKg;
    double rate = 0.0;
    final first10 = math.min(10.0, remaining);
    rate += first10 * 4.0;
    remaining -= first10;
    if (remaining > 0) {
      final next10 = math.min(10.0, remaining);
      rate += next10 * 2.0;
      remaining -= next10;
    }
    if (remaining > 0) {
      rate += remaining * 1.0;
    }
    return rate; // ml/hour
  }

  // Defibrillation energy (J): 4 J/kg
  static double defibrillationEnergyJ(double weightKg) => weightKg * 4.0;

  // Blood volume ~80 ml/kg
  static double bloodVolumeMl(double weightKg) => weightKg * 80.0;

  // Shock index = HR / systolic BP
  static double shockIndex({required double heartRate, required double systolicBP}) {
    if (systolicBP <= 0) return 0.0;
    return heartRate / systolicBP;
  }

  // Oxygen consumption rough: children ~6 ml/kg/min, neonates ~8 ml/kg/min
  static double oxygenConsumptionMlPerMin({required double weightKg, bool neonate = false}) {
    return weightKg * (neonate ? 8.0 : 6.0);
  }

  /// Empfohlenes Flussratenintervall für High‑Flow‑Sauerstofftherapie (L/min).
  ///
  /// Für Säuglinge bis 12 kg werden 2 L/kg/min empfohlen. Für ältere Kinder
  /// greifen feste Bereiche: 13–15 kg → 25–30 L/min, 16–30 kg → 35 L/min,
  /// 31–50 kg → 40 L/min, >50 kg → 50 L/min【632237024789058†L160-L176】.
  /// Gibt ein Tupel mit [minFlow, maxFlow] zurück. Bei Säuglingen wird
  /// minFlow == maxFlow sein.
  static List<double> highFlowOxygenRange(double weightKg) {
    if (weightKg <= 0) return [0.0, 0.0];
    if (weightKg <= 12.0) {
      final flow = weightKg * 2.0;
      return [flow, flow];
    }
    if (weightKg <= 15.0) {
      return [25.0, 30.0];
    }
    if (weightKg <= 30.0) {
      return [35.0, 35.0];
    }
    if (weightKg <= 50.0) {
      return [40.0, 40.0];
    }
    return [50.0, 50.0];
  }

  /// Berechnet die Insulininfusionsdosis bei diabetischer Ketoazidose in
  /// Einheiten pro Stunde für ein gegebenes Körpergewicht. Die meisten
  /// Leitlinien empfehlen eine Dauerinfusion von 0,05 bis 0,1 U/kg/h nach
  /// ausreichender Volumenresuscitation【576050331524418†L438-L445】.
  static List<double> dkaInsulinDoseRange(double weightKg) {
    if (weightKg <= 0) return [0.0, 0.0];
    final minDose = weightKg * 0.05;
    final maxDose = weightKg * 0.10;
    return [minDose, maxDose];
  }

  /// Temperaturumrechnung Fahrenheit→Celsius.
  static double fahrenheitToCelsius(double fahrenheit) {
    return (fahrenheit - 32.0) / 1.8;
  }

  /// Temperaturumrechnung Celsius→Fahrenheit.
  static double celsiusToFahrenheit(double celsius) {
    return (celsius * 1.8) + 32.0;
  }

  // Equipment helpers (examples)
  static double tubeSizeNoCuff(double years) => (years / 4.0) + 4.0;
  static double tubeSizeCuff(double years) => (years / 4.0) + 3.5;
  static double tubeDepthCm(double years) => (years / 2.0) + 12.0;
  static String laryngealTubeSizeByWeight(double weightKg) {
    if (weightKg < 10.0) return '2';
    if (weightKg <= 20.0) return '2.5';
    return '3';
  }
}
