import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import '../models/schema.dart';

/// Service zum Laden der Schemata aus der lokalen JSON‑Datei.
/// Die Schemata befinden sich in assets/data/schemata.json und umfassen
/// strukturelle Notfall‑Mnemonics wie xABCDE, SAMPLER, BAK sowie Geburtschecklisten.
class SchemaService {
  static const String _assetPath = 'assets/data/schemata.json';

  /// Liefert alle verfügbaren Schemata als Liste zurück.
  Future<List<Schema>> getAllSchemata() async {
    final data = await rootBundle.loadString(_assetPath);
    final List<dynamic> jsonList = json.decode(data);
    return jsonList
        .map((e) => Schema.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
  }
}